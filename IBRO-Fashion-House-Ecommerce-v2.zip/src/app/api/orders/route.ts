import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
function normalizeBdPhone(input:string){let p=input.replace(/[^0-9+]/g,"");if(p.startsWith("+"))p=p.slice(1);if(p.startsWith("880"))return p;if(p.startsWith("0"))return "88"+p;return p;}
async function sendWhatsApp(message:string){
 const token=process.env.WHATSAPP_ACCESS_TOKEN, phoneId=process.env.WHATSAPP_PHONE_NUMBER_ID, recipient=process.env.WHATSAPP_ADMIN_PHONE;
 if(!token||!phoneId||!recipient)return {sent:false,reason:"WhatsApp credentials are not configured"};
 const version=process.env.WHATSAPP_API_VERSION||"v22.0";
 const response=await fetch(`https://graph.facebook.com/${version}/${phoneId}/messages`,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify({messaging_product:"whatsapp",to:normalizeBdPhone(recipient),type:"text",text:{preview_url:false,body:message}})});
 const result=await response.json();return {sent:response.ok,result};
}
export async function POST(req:Request){
 try{
  if(!supabaseUrl||!serviceKey)return NextResponse.json({error:"সার্ভারের Supabase সেটআপ সম্পন্ন হয়নি। অ্যাডমিনকে জানান।"},{status:503});
  const body=await req.json();const {customer,items}=body;
  if(!customer?.name||!customer?.phone||!customer?.address||!Array.isArray(items)||items.length===0)return NextResponse.json({error:"নাম, ফোন, ঠিকানা ও পণ্য নির্বাচন সম্পূর্ণ করুন।"},{status:400});
  if(!["cod","bkash","nagad"].includes(customer.payment_method))return NextResponse.json({error:"পেমেন্ট পদ্ধতি সঠিক নয়।"},{status:400});
  if(customer.payment_method!=="cod"&&!customer.transaction_id?.trim())return NextResponse.json({error:"পেমেন্ট Transaction ID দিন।"},{status:400});
  const admin=createClient(supabaseUrl,serviceKey,{auth:{persistSession:false}});
  const ids=items.map((i:any)=>String(i.product_id));
  const {data:products,error:productError}=await admin.from("products").select("id,name,sku,price,stock").in("id",ids);
  if(productError||!products||products.length!==ids.length)return NextResponse.json({error:"এক বা একাধিক পণ্য আর উপলভ্য নেই।"},{status:409});
  const lines=items.map((i:any)=>{const p=products.find(x=>x.id===String(i.product_id));const qty=Number(i.quantity);if(!p||!Number.isInteger(qty)||qty<1||qty>p.stock)throw new Error(`“${p?.name||"পণ্য"}” পর্যাপ্ত স্টকে নেই।`);return {product_id:p.id,product_name:p.name,sku:p.sku,quantity:qty,unit_price:Number(p.price),line_total:Number(p.price)*qty};});
  const total=lines.reduce((s,l)=>s+l.line_total,0);const orderNumber=`IBRO-${Date.now().toString().slice(-9)}`;
  const {data:order,error:orderError}=await admin.from("orders").insert({order_number:orderNumber,customer_name:String(customer.name).trim(),customer_phone:String(customer.phone).trim(),customer_address:String(customer.address).trim(),payment_method:customer.payment_method,payment_transaction_id:customer.transaction_id||null,payment_status:customer.payment_method==="cod"?"unpaid":"verification_pending",notes:customer.notes||null,total_amount:total,status:"pending"}).select("id").single();
  if(orderError)throw orderError;
  const {error:itemError}=await admin.from("order_items").insert(lines.map(l=>({...l,order_id:order.id})));
  if(itemError){await admin.from("orders").delete().eq("id",order.id);throw itemError;}
  const paymentLabel=customer.payment_method==="cod"?"Cash on Delivery":customer.payment_method.toUpperCase();
  const msg=[`🛍️ নতুন অর্ডার: ${orderNumber}`,`নাম: ${customer.name}`,`ফোন: ${customer.phone}`,`ঠিকানা: ${customer.address}`,`পেমেন্ট: ${paymentLabel}`,customer.transaction_id?`Transaction ID: ${customer.transaction_id}`:"",...lines.map(l=>`${l.product_name} × ${l.quantity} = ৳${l.line_total}`),`মোট: ৳${total}`,customer.notes?`নোট: ${customer.notes}`:""].filter(Boolean).join("\n");
  let wa: {sent:boolean; reason?:string; result?:unknown}={sent:false,reason:"WhatsApp credentials are not configured"};try{wa=await sendWhatsApp(msg)}catch(e){console.error("WhatsApp send failed",e)}
  await admin.from("orders").update({whatsapp_notified:wa.sent,whatsapp_error:wa.sent?null:JSON.stringify(wa).slice(0,500)}).eq("id",order.id);
  return NextResponse.json({ok:true,order_number:orderNumber,whatsapp_notified:wa.sent});
 }catch(e){console.error("Order create error",e);return NextResponse.json({error:e instanceof Error?e.message:"অর্ডার সম্পন্ন করা যায়নি।"},{status:500});}
}
